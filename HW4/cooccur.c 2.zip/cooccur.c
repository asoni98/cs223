#include <stdio.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "smap.h"
#include "cooccur.h"
#include <string.h>


//you just need two smaps to make the cooccur struct


//use get line to read in from main
//make buffer size 1024 characters

struct cooccurrence_matrix
{
  int numWords;
  smap *keywords;
  smap *words;
};

void print_entry(const char *key, int *value)
{
  if (key != NULL && value != NULL)
    {
      printf("%s = %d\n", key, *value);
    }
}

int really_bad_string_hash(const char *key)
{
  if (key == NULL)
    {
      return 0;
    }
  else
    {
      // key hashes to ASCII value of first character
      // (this does *not* achieve the goal of spreading all possible keys
      // uniformly and pseudo-randomly across the range of an int)
      // but the current smap implementation does't even use hashing, so whatevs
      return *key;
    }
}

/**
 * Creates a cooccurrence matrix that counts cooccurrences of the given keywords
 * and is initialized to 0 for all entries.
 *
 * @param key an array of distinct non-NULL strings, non-NULL
 * @param n the size of that array
 * @return a pointer to a new cooccurrence matrix; the caller is responsible for
 * destroying the matrix
 */
cooccurrence_matrix *cooccur_create(char *key[], int n) {
  cooccurrence_matrix *result = malloc(sizeof(cooccurrence_matrix));
  if (result != NULL)
    {
      result->numWords = n;
      result->keywords = smap_create(really_bad_string_hash); //change hashing function
      result->words = smap_create(really_bad_string_hash);

      for (int i = 0; i < n; i++) {
        int *j = malloc(sizeof(int));
        //if number not equal to null
        *j = i;
        smap_put(result->keywords, key[i], j);
      }

      result->words = malloc(sizeof(int *) * n);
      // for (int i = 0; i < n; i++) {
      //   (result->words)[i] = malloc(n);
      // }
      // for (int i = 0; i < n; i++) {
      //
      // }
      int *z;
      for (int i = 0; i < 3; i++) {
        z = malloc(sizeof(int) * n);
        for (int j = 0; j < 3; j++) {
          z[j] = 0;
          printf("%d\n", z[j]);
        }
        smap_put(result->words, key[i], z);
      }
    }

  return result;
}

/**
 * Updates the given cooccurrence matrix by incrementing the counts for
 * each pair of keywords in the given context.
 *
 * @param mat a pointer to a cooccurrence matrix, non-NULL
 * @param context an array of distinct non-NULL strings that are keywords
 * for that matrix, non-NULL
 * @param n the size of that array
 */


// void cooccur_update(cooccurrence_matrix *mat, char **context, int n) {
//   for (int i = 0; i < n; i++) {
//     for (int j = 0; j < n; j++) {
//       // smap *counts = smap_create(really_bad_string_hash);
//       // int *varHold = smap_get(counts, "abd");
//
//       int *word_index = smap_get(mat->keywords, context[i]);
//       int *other_word_index = smap_get(mat->keywords, context[j]);
//       if (word_index != NULL && other_word_index != NULL) {mat->words[*word_index][*other_word_index]++;}
//       //mat->words[*other_word_index][*word_index]++;
//     }
//   }
// }

/**
 * Reads keywords from the given matrix from the current line of the given stream.
 * A keyword is considered to have been read if it appears on the stream before
 * the next newline surrounded by whitespace, the beginning of input (as seen by
 * this function), or EOF.  The newline is read and removed from the stream.
 *
 * @param mat a pointer to a cooccurrence matrix, non-NULL
 * @param stream a stream, non-NULL
 * @param n a pointer to an int where the size of the returned array will be written
 * @return an array of unique non-NULL strings containing all the keywords read;
 * the caller is responsible for deallocating the array and the strings it contains
 */
// char **cooccur_read_context(cooccurrence_matrix *mat, FILE *stream, int *n) {
//   char *buffer;
//   size_t bufsize = 1000; //make dynamic
//   size_t characters;
//   buffer = (char *)malloc(bufsize * sizeof(char));
//   if( buffer == NULL)
//   {
//       perror("Unable to allocate buffer");
//       exit(1);
//   }
//   characters = getline(&buffer, &bufsize, stream);
//   //printf("%zu characters were read.\n",characters);
//   //printf("You typed: '%s'\n",buffer);
//
//     int i = 0;
//     char *p = strtok (buffer, " ");
//     char *array[3];
//
//     while (p != NULL)
//     {
//         array[i++] = p;
//         p = strtok (NULL, " ");
//     }
//
//     // for (i = 0; i < 3; ++i)
//     //     printf("%s\n", array[i]);
//
//     //check for distinctiveness somehow
//     //create an smap and check if the number occurs multiple times
//     //smap *smap_create(int (*h)(const char *s))
//
//     smap *keywordsNew = smap_create(really_bad_string_hash);
//     for (int i = 0; i < 3; i++) {
//       int *j = malloc(sizeof(int));
//       *j = 1;
//
//       //printf("%d", smap_contains_key(mat->keywords, array[i]));
//       printf("Array value: %s\n", array[i]);
//        if (smap_contains_key(mat->keywords, array[i])) {
//          if (smap_put(keywordsNew, array[i], j) == false) {
//            printf("ERROR");
//          }
//          //printf("1");
//      }
//   }
//   // if (value = 1) {}
//   smap_for_each(keywordsNew, print_entry);
// }





void printCMatrix(cooccurrence_matrix *l) {
  printf("Num Words: %d\n", l->numWords);
  printf("Keywords:\n");
  smap_for_each(l->keywords, print_entry);
  printf("\nValues: [");
  for (int i = 0; i < l->numWords; i++) {
      printf("[");
    for (int j = 0; j < l->numWords; j++) {
      smap_for_each(l->words, print_entry);
    }
    printf("], ");
  }
  printf("]\n");
  //do something with smaps
}

int main(int argc, char **argv)
{
  char *string[3] = {"cbc", "bbd", "aux"};
  //char *string2[2] = {"cbc", "bbd"};
  //char *string1[3] = {"dbc", "ebd", "fux"};
//  char *string1 = "abd";
  cooccurrence_matrix *coPointer = cooccur_create(string, 3);
  printf("a1 %d\n", smap_contains_key(coPointer->keywords, "cbc"));
  printf("a2 %d\n", smap_contains_key(coPointer->keywords, "bbd"));
  printf("a3 %d\n", smap_contains_key(coPointer->keywords, "aux"));

  //cooccur_update(coPointer, string2, 2);
  //printCMatrix(coPointer);
  int var = 3;
  //cooccur_read_context(coPointer, stdin, &var);
  printCMatrix(coPointer);



}
